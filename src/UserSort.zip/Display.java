
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.*;

public class Display extends JFrame implements MouseListener{

	private JFrame frame;
	
//	private ArrayList<Card> cards;
	
	public Display(){
//		cards = new ArrayList<Card>();
		frame = new JFrame("The Manager");
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		JTextPane textPane = new JTextPane();
		textPane.setBounds(10, 11, 177, 118);
		textPane.setText("Pros");
		getContentPane().add(textPane);
		
		JTextPane textPane_1 = new JTextPane();
		textPane_1.setBounds(197, 11, 177, 118);
		getContentPane().add(textPane_1);
		
		JTextPane textPane_2 = new JTextPane();
		textPane_2.setBounds(20, 140, 177, 111);
		getContentPane().add(textPane_2);
		
		JFormattedTextField formattedTextField = new JFormattedTextField();
		formattedTextField.setBounds(207, 140, 177, 111);
		getContentPane().add(formattedTextField);
	}
	
	/*
	 * returns -1 if Card at index1 is seen as less than Card at
	 * index2, 0 if equal, and 1 if greater than
	 */
	public int compare(int index1, int index2){
		return 0;
	}
	
	public static void main(String[] args){
		Display display = new Display();
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}
