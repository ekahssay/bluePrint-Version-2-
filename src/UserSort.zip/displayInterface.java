
import java.util.ArrayList;

/**
 * Created by endrias on 2/28/2016.
 */
public interface displayInterface {
    public int compare(int index1, int index2);
    public void display(ArrayList<Card> sortedCards);
}
