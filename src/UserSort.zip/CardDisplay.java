
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.*;

public class CardDisplay extends JComponent{

	private int xCoor;
	private int yCoor;
	private int width;
	private int height;
	private Card card;
	
	public CardDisplay(){
		
	}
	
	public void paintComponent(Graphics g){
		Graphics2D g2 = (Graphics2D) g;
		
	}
	
}
